<?php
/*
I have tested it from PHP 5.6 to PHP 8.2 versions, it is working smoothly on all PHP versions
*/
session_start();
if(session_destroy()) // Destroying All Sessions
{
header("Location: login.php"); // Redirecting To Home Page
exit();
}
?>