<?php
/*
I have tested it from PHP 5.6 to PHP 8.2 versions, it is working smoothly on all PHP versions
*/
?>
<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: login.php");
exit(); }
?>