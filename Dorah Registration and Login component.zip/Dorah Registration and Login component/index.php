<?php
/*
I have tested it from PHP 5.6 to PHP 8.2 versions, it is working smoothly on all PHP versions
*/
include("auth.php"); //include auth.php file on all secure pages ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Home</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>
<p>This is our new world.</p>
<p><a href="dashboard.php">Dashboard</a></p>
<a href="logout.php">Logout</a>

</div>
</body>
</html>